﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    class ClsMultiplicacion
    {
        public double Multiplicar(double N1, double N2)
        {
            double m;
            m = N1 * N2;
            return m;
        }
    }
}
