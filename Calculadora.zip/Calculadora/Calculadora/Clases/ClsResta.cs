﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    class ClsResta
    {
        public double Restar(double N1, double N2)
        {
            double r;
            r = N1 - N2;
            return r;
        }
    }
}
