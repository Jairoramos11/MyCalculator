﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora.Clases
{
    class ClsDivision
    {
        public double Dividir(double N1, double N2)
        {
            double d;
            d = N1 / N2;
            return d;
        }
    }
}
 