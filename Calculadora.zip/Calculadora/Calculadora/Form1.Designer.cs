﻿namespace Calculadora
{
    partial class Calc
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calc));
            this.sumar = new System.Windows.Forms.Button();
            this.btnresta = new System.Windows.Forms.Button();
            this.division = new System.Windows.Forms.Button();
            this.multiplicar = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btnborrar = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnseis = new System.Windows.Forms.Button();
            this.btnsiete = new System.Windows.Forms.Button();
            this.btbocho = new System.Windows.Forms.Button();
            this.btbcinco = new System.Windows.Forms.Button();
            this.btnnegativo = new System.Windows.Forms.Button();
            this.btncuatro = new System.Windows.Forms.Button();
            this.btbnueve = new System.Windows.Forms.Button();
            this.btnpunto = new System.Windows.Forms.Button();
            this.btncero = new System.Windows.Forms.Button();
            this.btnporcentaje = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.btndos = new System.Windows.Forms.Button();
            this.btnuno = new System.Windows.Forms.Button();
            this.btntres = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tboxresultado = new System.Windows.Forms.TextBox();
            this.tboxoperacion = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // sumar
            // 
            this.sumar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(129)))), ((int)(((byte)(129)))));
            this.sumar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.sumar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sumar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sumar.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sumar.ForeColor = System.Drawing.Color.White;
            this.sumar.Location = new System.Drawing.Point(250, 259);
            this.sumar.Margin = new System.Windows.Forms.Padding(0);
            this.sumar.Name = "sumar";
            this.sumar.Size = new System.Drawing.Size(83, 55);
            this.sumar.TabIndex = 0;
            this.sumar.Text = "+";
            this.sumar.UseVisualStyleBackColor = false;
            this.sumar.Click += new System.EventHandler(this.sumar_Click);
            // 
            // btnresta
            // 
            this.btnresta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(129)))), ((int)(((byte)(129)))));
            this.btnresta.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnresta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnresta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnresta.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresta.ForeColor = System.Drawing.Color.White;
            this.btnresta.Location = new System.Drawing.Point(250, 314);
            this.btnresta.Margin = new System.Windows.Forms.Padding(0);
            this.btnresta.Name = "btnresta";
            this.btnresta.Size = new System.Drawing.Size(83, 55);
            this.btnresta.TabIndex = 1;
            this.btnresta.Text = "-";
            this.btnresta.UseVisualStyleBackColor = false;
            this.btnresta.Click += new System.EventHandler(this.btnresta_Click);
            // 
            // division
            // 
            this.division.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(129)))), ((int)(((byte)(129)))));
            this.division.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.division.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.division.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.division.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.division.ForeColor = System.Drawing.Color.White;
            this.division.Location = new System.Drawing.Point(250, 149);
            this.division.Margin = new System.Windows.Forms.Padding(0);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(83, 55);
            this.division.TabIndex = 2;
            this.division.Text = "/";
            this.division.UseVisualStyleBackColor = false;
            this.division.Click += new System.EventHandler(this.division_Click);
            // 
            // multiplicar
            // 
            this.multiplicar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(129)))), ((int)(((byte)(129)))));
            this.multiplicar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.multiplicar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.multiplicar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiplicar.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiplicar.ForeColor = System.Drawing.Color.White;
            this.multiplicar.Location = new System.Drawing.Point(250, 204);
            this.multiplicar.Margin = new System.Windows.Forms.Padding(0);
            this.multiplicar.Name = "multiplicar";
            this.multiplicar.Size = new System.Drawing.Size(83, 55);
            this.multiplicar.TabIndex = 3;
            this.multiplicar.Text = "*";
            this.multiplicar.UseCompatibleTextRendering = true;
            this.multiplicar.UseVisualStyleBackColor = false;
            this.multiplicar.Click += new System.EventHandler(this.multiplicar_Click);
            // 
            // btnigual
            // 
            this.btnigual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(28)))), ((int)(((byte)(11)))));
            this.btnigual.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnigual.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnigual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnigual.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnigual.ForeColor = System.Drawing.Color.White;
            this.btnigual.Location = new System.Drawing.Point(250, 369);
            this.btnigual.Margin = new System.Windows.Forms.Padding(0);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(83, 55);
            this.btnigual.TabIndex = 5;
            this.btnigual.Text = "=";
            this.btnigual.UseVisualStyleBackColor = false;
            this.btnigual.Click += new System.EventHandler(this.btnigual_Click);
            // 
            // btnborrar
            // 
            this.btnborrar.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnborrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrar.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnborrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnborrar.Location = new System.Drawing.Point(1, 149);
            this.btnborrar.Name = "btnborrar";
            this.btnborrar.Size = new System.Drawing.Size(83, 55);
            this.btnborrar.TabIndex = 5;
            this.btnborrar.Text = "<";
            this.btnborrar.UseVisualStyleBackColor = true;
            // 
            // btnclear
            // 
            this.btnclear.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclear.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnclear.Location = new System.Drawing.Point(84, 149);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(83, 55);
            this.btnclear.TabIndex = 8;
            this.btnclear.Text = "CE";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnseis
            // 
            this.btnseis.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnseis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnseis.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnseis.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnseis.Location = new System.Drawing.Point(167, 259);
            this.btnseis.Name = "btnseis";
            this.btnseis.Size = new System.Drawing.Size(83, 55);
            this.btnseis.TabIndex = 9;
            this.btnseis.Text = "6";
            this.btnseis.UseVisualStyleBackColor = true;
            this.btnseis.Click += new System.EventHandler(this.btnseis_Click);
            // 
            // btnsiete
            // 
            this.btnsiete.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnsiete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsiete.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsiete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsiete.Location = new System.Drawing.Point(1, 204);
            this.btnsiete.Name = "btnsiete";
            this.btnsiete.Size = new System.Drawing.Size(83, 55);
            this.btnsiete.TabIndex = 12;
            this.btnsiete.Text = "7";
            this.btnsiete.UseVisualStyleBackColor = true;
            this.btnsiete.Click += new System.EventHandler(this.btnsiete_Click);
            // 
            // btbocho
            // 
            this.btbocho.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btbocho.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btbocho.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbocho.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btbocho.Location = new System.Drawing.Point(84, 204);
            this.btbocho.Name = "btbocho";
            this.btbocho.Size = new System.Drawing.Size(83, 55);
            this.btbocho.TabIndex = 11;
            this.btbocho.Text = "8";
            this.btbocho.UseVisualStyleBackColor = true;
            this.btbocho.Click += new System.EventHandler(this.btbocho_Click);
            // 
            // btbcinco
            // 
            this.btbcinco.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btbcinco.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btbcinco.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbcinco.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btbcinco.Location = new System.Drawing.Point(84, 259);
            this.btbcinco.Name = "btbcinco";
            this.btbcinco.Size = new System.Drawing.Size(83, 55);
            this.btbcinco.TabIndex = 10;
            this.btbcinco.Text = "5";
            this.btbcinco.UseVisualStyleBackColor = true;
            this.btbcinco.Click += new System.EventHandler(this.btbcinco_Click);
            // 
            // btnnegativo
            // 
            this.btnnegativo.BackColor = System.Drawing.Color.Black;
            this.btnnegativo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnnegativo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnegativo.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnegativo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnnegativo.Location = new System.Drawing.Point(167, 369);
            this.btnnegativo.Name = "btnnegativo";
            this.btnnegativo.Size = new System.Drawing.Size(83, 55);
            this.btnnegativo.TabIndex = 15;
            this.btnnegativo.Text = "+/-";
            this.btnnegativo.UseVisualStyleBackColor = false;
            // 
            // btncuatro
            // 
            this.btncuatro.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btncuatro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncuatro.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncuatro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btncuatro.Location = new System.Drawing.Point(1, 259);
            this.btncuatro.Name = "btncuatro";
            this.btncuatro.Size = new System.Drawing.Size(83, 55);
            this.btncuatro.TabIndex = 14;
            this.btncuatro.Text = "4";
            this.btncuatro.UseVisualStyleBackColor = true;
            this.btncuatro.Click += new System.EventHandler(this.btncuatro_Click);
            // 
            // btbnueve
            // 
            this.btbnueve.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btbnueve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btbnueve.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbnueve.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btbnueve.Location = new System.Drawing.Point(167, 204);
            this.btbnueve.Name = "btbnueve";
            this.btbnueve.Size = new System.Drawing.Size(83, 55);
            this.btbnueve.TabIndex = 13;
            this.btbnueve.Text = "9";
            this.btbnueve.UseVisualStyleBackColor = true;
            this.btbnueve.Click += new System.EventHandler(this.btbnueve_Click);
            // 
            // btnpunto
            // 
            this.btnpunto.BackColor = System.Drawing.Color.Black;
            this.btnpunto.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnpunto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpunto.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpunto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnpunto.Location = new System.Drawing.Point(1, 369);
            this.btnpunto.Name = "btnpunto";
            this.btnpunto.Size = new System.Drawing.Size(83, 55);
            this.btnpunto.TabIndex = 18;
            this.btnpunto.Text = ".";
            this.btnpunto.UseVisualStyleBackColor = false;
            this.btnpunto.Click += new System.EventHandler(this.btnpunto_Click);
            // 
            // btncero
            // 
            this.btncero.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btncero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncero.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncero.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btncero.Location = new System.Drawing.Point(84, 369);
            this.btncero.Name = "btncero";
            this.btncero.Size = new System.Drawing.Size(83, 55);
            this.btncero.TabIndex = 17;
            this.btncero.Text = "0";
            this.btncero.UseVisualStyleBackColor = true;
            this.btncero.Click += new System.EventHandler(this.btncero_Click);
            // 
            // btnporcentaje
            // 
            this.btnporcentaje.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnporcentaje.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnporcentaje.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnporcentaje.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnporcentaje.Location = new System.Drawing.Point(167, 149);
            this.btnporcentaje.Name = "btnporcentaje";
            this.btnporcentaje.Size = new System.Drawing.Size(83, 55);
            this.btnporcentaje.TabIndex = 16;
            this.btnporcentaje.Text = "%";
            this.btnporcentaje.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Maroon;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(299, -1);
            this.button7.Margin = new System.Windows.Forms.Padding(0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(32, 14);
            this.button7.TabIndex = 4;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btndos
            // 
            this.btndos.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btndos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndos.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btndos.Location = new System.Drawing.Point(84, 314);
            this.btndos.Name = "btndos";
            this.btndos.Size = new System.Drawing.Size(83, 55);
            this.btndos.TabIndex = 17;
            this.btndos.Text = "2";
            this.btndos.UseVisualStyleBackColor = true;
            this.btndos.Click += new System.EventHandler(this.btndos_Click);
            // 
            // btnuno
            // 
            this.btnuno.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnuno.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuno.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuno.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnuno.Location = new System.Drawing.Point(1, 314);
            this.btnuno.Name = "btnuno";
            this.btnuno.Size = new System.Drawing.Size(83, 55);
            this.btnuno.TabIndex = 18;
            this.btnuno.Text = "1";
            this.btnuno.UseVisualStyleBackColor = true;
            this.btnuno.Click += new System.EventHandler(this.btnuno_Click);
            // 
            // btntres
            // 
            this.btntres.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btntres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btntres.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntres.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btntres.Location = new System.Drawing.Point(167, 314);
            this.btntres.Name = "btntres";
            this.btntres.Size = new System.Drawing.Size(83, 55);
            this.btntres.TabIndex = 15;
            this.btntres.Text = "3";
            this.btntres.UseVisualStyleBackColor = true;
            this.btntres.Click += new System.EventHandler(this.btntres_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(267, -1);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(32, 14);
            this.button2.TabIndex = 20;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tboxresultado
            // 
            this.tboxresultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(7)))), ((int)(((byte)(66)))));
            this.tboxresultado.Font = new System.Drawing.Font("Lucida Fax", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxresultado.Location = new System.Drawing.Point(1, 88);
            this.tboxresultado.Name = "tboxresultado";
            this.tboxresultado.ReadOnly = true;
            this.tboxresultado.Size = new System.Drawing.Size(332, 58);
            this.tboxresultado.TabIndex = 21;
            // 
            // tboxoperacion
            // 
            this.tboxoperacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(7)))), ((int)(((byte)(66)))));
            this.tboxoperacion.Font = new System.Drawing.Font("alarm clock", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tboxoperacion.ForeColor = System.Drawing.SystemColors.Info;
            this.tboxoperacion.Location = new System.Drawing.Point(1, 35);
            this.tboxoperacion.Name = "tboxoperacion";
            this.tboxoperacion.ReadOnly = true;
            this.tboxoperacion.Size = new System.Drawing.Size(332, 57);
            this.tboxoperacion.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(7)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(334, 423);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tboxoperacion);
            this.Controls.Add(this.tboxresultado);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btntres);
            this.Controls.Add(this.btnnegativo);
            this.Controls.Add(this.btncuatro);
            this.Controls.Add(this.btbnueve);
            this.Controls.Add(this.btnsiete);
            this.Controls.Add(this.btbocho);
            this.Controls.Add(this.btbcinco);
            this.Controls.Add(this.btnseis);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnborrar);
            this.Controls.Add(this.multiplicar);
            this.Controls.Add(this.division);
            this.Controls.Add(this.btnresta);
            this.Controls.Add(this.btnuno);
            this.Controls.Add(this.sumar);
            this.Controls.Add(this.btndos);
            this.Controls.Add(this.btnpunto);
            this.Controls.Add(this.btncero);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btnporcentaje);
            this.Controls.Add(this.btnigual);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Calc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sumar;
        private System.Windows.Forms.Button btnresta;
        private System.Windows.Forms.Button division;
        private System.Windows.Forms.Button multiplicar;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btnborrar;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnseis;
        private System.Windows.Forms.Button btnsiete;
        private System.Windows.Forms.Button btbocho;
        private System.Windows.Forms.Button btbcinco;
        private System.Windows.Forms.Button btnnegativo;
        private System.Windows.Forms.Button btncuatro;
        private System.Windows.Forms.Button btbnueve;
        private System.Windows.Forms.Button btnpunto;
        private System.Windows.Forms.Button btncero;
        private System.Windows.Forms.Button btnporcentaje;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btndos;
        private System.Windows.Forms.Button btnuno;
        private System.Windows.Forms.Button btntres;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tboxresultado;
        private System.Windows.Forms.TextBox tboxoperacion;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

