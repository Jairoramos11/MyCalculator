﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Calc : Form
    {
        double primero;
        double segundo;
        string operador;

        public Calc()
        {
            InitializeComponent();
        }
        Clases.ClsSuma obj = new Clases.ClsSuma();
        Clases.ClsResta obj2 = new Clases.ClsResta();
        Clases.ClsMultiplicacion obj3 = new Clases.ClsMultiplicacion();
        Clases.ClsDivision obj4 = new Clases.ClsDivision();

        private void btnuno_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text += "1";
        }

        private void btndos_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "2";
        }

        private void btntres_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "3";
        }

        private void btncuatro_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "4";
        }

        private void btbcinco_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "5";
        }

        private void btnseis_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "6";
        }

        private void btnsiete_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "7";
        }

        private void btbocho_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "8";
        }

        private void btbnueve_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "9";
        }

        private void btncero_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + "0";
        }

        private void btnpunto_Click(object sender, EventArgs e)
        {
            tboxoperacion.Text = tboxoperacion.Text + ".";
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            tboxoperacion.Clear() ;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void division_Click(object sender, EventArgs e)
        {
            
            operador = "/";
            primero = double.Parse(tboxoperacion.Text);
            tboxoperacion.Clear();
        }

        private void multiplicar_Click(object sender, EventArgs e)
        {
            operador = "*";
            primero = double.Parse(tboxoperacion.Text);
            tboxoperacion.Clear();
        }

        private void sumar_Click(object sender, EventArgs e)
        {
            operador = "+";
            primero = double.Parse(tboxoperacion.Text);
            tboxoperacion.Clear();
        }

        private void btnresta_Click(object sender, EventArgs e)
        {
            operador = "-";
            primero = double.Parse(tboxoperacion.Text);
            tboxoperacion.Clear();
        }

        private void btnigual_Click(object sender, EventArgs e)
        {
            segundo = double.Parse(tboxresultado.Text);
        }
    }
}
